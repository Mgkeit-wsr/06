user = {}
user[1]={}
user[1][2]  = 3

print(user[1])