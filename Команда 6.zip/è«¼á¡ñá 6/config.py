HOST = "s2.tritix.org"
USER = "hakaton"
PASSWORD = "hakaton2022"
DB_NAME = "bot"
DEVELOPERS = ["gervantunderscore", "gaprixdev", "SaltyBread"]
admins = [384103834]
CATEGORIES = ["Спорт", "Музыка", "Настольные игры", "Общение", "На улице", "Дома", "В ресторане"]
